#include "BookList.h"
#include "BookNode.h"
#include <string>
#include <fstream>
using namespace  std;


BookList::BookList(const string name): name(name), head(nullptr), tail(nullptr)
{
    cout<<"constructor"<<endl;
    create();
}

void BookList::print(BookNode* nodeptr)
{
    Book book = nodeptr->getbook();
    cout<<book;
    while(nodeptr->getnext())
    {
    cout<<book;
    nodeptr = nodeptr->getnext();
    }
}
BookNode* BookList::getHead()
{
    return head;
}
void BookList::insertNode(BookNode* NodeToInsert)
{
    BookNode * newnode= NodeToInsert;
    if(head==nullptr)
    {
        head = NodeToInsert;
        tail = NodeToInsert;
        return ;
    }
    else if(((head->getbook()).getISBN())  >  (newnode->getbook()).getISBN())
    {
        cout<<"small";
        BookNode* NodeToInsertNext = NodeToInsert->getnext();
        NodeToInsertNext = head;
        head =NodeToInsert;
        
    }
    else if(((head->getbook()).getISBN())  <=  (newnode->getbook()).getISBN()){
        cout<<"less";
        BookNode* ptr = head;
        while(ptr!= tail)
        {
            if(ptr->getnext()->getbook().getISBN()==NodeToInsert->getbook().getISBN())
            {
            return;
            }
            else if(ptr->getnext()->getbook().getISBN()<NodeToInsert->getbook().getISBN())
            {
                ptr=ptr->getnext();
            }
            else{
                break;
            }
        }
        NodeToInsert->setnext(ptr->getnext());
        ptr->setnext(NodeToInsert);
            if(ptr==tail)
            {
                tail = NodeToInsert;
            }
        }
}

void BookList::create()
{
    if(name=="science")
    {
        int count = 0;
        ifstream scienceFile;
        string scienceString;
        scienceFile.open("science.txt");
        if(scienceFile.fail())
            cout << "File failed to open science.txt" << endl;
        else
            cout<<"Book List: science"<<endl<<endl;
        while(!scienceFile.eof()){
            getline(scienceFile,scienceString);
            Book newBook(scienceString);
            BookNode newNode(newBook);
            insertNode(&newNode);
            count++;
        }
        print(head);
        cout<<endl<<"("<<count<<" Books)"<<endl<<endl;
    }
    
    else if(name=="history")
    {
        int count = 0;
        ifstream historyFile;
        string historyString;
        historyFile.open("history.txt");
        if(historyFile.fail())
            cout << "File failed to open history.txt" << endl;
        else
            cout<<"Book List: history"<<endl<<endl;
        while(!historyFile.eof()){
            getline(historyFile,historyString);
            Book newBook(historyString);
            BookNode newNode(newBook);
            insertNode(&newNode);
            count++;
        }
        print(head);
        cout<<endl<<"("<<count<<" Books)"<<endl<<endl;
    }
    else if(name=="mystery"){
        int count = 0;
        ifstream mysteryFile;
        string mysteryString;
        mysteryFile.open("mystery.txt");
        if(mysteryFile.fail())
            cout << "File failed to open mystery.txt" << endl;
        else
            cout<<"Book List: mystery"<<endl<<endl;
        while(!mysteryFile.eof()){
            getline(mysteryFile,mysteryString);
            Book newBook(mysteryString);
            BookNode newNode(newBook);
            insertNode(&newNode);
            count++;
        }
        print(head);
        cout<<endl<<"("<<count<<" Books)"<<endl<<endl;
    }
    else if(name=="childrens"){
        int count = 0;
        ifstream childrensFile;
        string childrensString;
        childrensFile.open("childrens.txt");
        if(childrensFile.fail())
            cout << "File failed to open science.txt" << endl;
        else
            cout<<"Book List: childrens"<<endl<<endl;
        while(!childrensFile.eof()){
            getline(childrensFile,childrensString);
            Book newBook(childrensString);
            BookNode newNode(newBook);
            insertNode(&newNode);
            count++;
        }
        print(head);
        cout<<endl<<"("<<count<<" Books)"<<endl<<endl;
    }
    else{
    }
    }

