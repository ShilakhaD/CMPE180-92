/***** Complete this file. *****/
#include "Book.h"
#include "BookNode.h"
#include "BookList.h"

BookNode::BookNode(Book newBook){
    book = newBook;
    next= nullptr;
}

BookNode::BookNode(){
  (BookNode*)malloc(sizeof(BookNode));
}

BookNode* BookNode::getnext()
{
    return next;
}

void BookNode::setnext(BookNode* node)
{
     this->next =  next;
}
Book BookNode::getbook()
{
    return book;
}
