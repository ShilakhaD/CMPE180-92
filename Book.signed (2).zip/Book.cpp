/***** Complete this file. *****/
#include <iostream>
#include <string.h>
using namespace std;
#include "BookNode.h"
#include "Book.h"

Book::Book(string bookdetails)
{
    vector<string> arr = split_the_string(bookdetails,",");
    ISBN = arr[0];
    first = arr[1];
    last = arr[2];
    title = arr[3];
}

Book::Book()
{
    ISBN = "";
    first = "";
    last = "";
    title = "";
}

ostream &operator<<(ostream &out, Book& book)
{
    out<<"Book{ISBN="<<book.ISBN<<", "<<"last="<<book.last<<", "<<"first="<<book.first<<", "<<"title="<<book.title<<"}"<<endl;
    return out;
}

vector<string> Book::split_the_string(string str,string sep){
    char* cstr=const_cast<char*>(str.c_str());
    char* current;
    vector<string> arr;
    current=strtok(cstr,sep.c_str());
    while(current!=NULL){
        arr.push_back(current);
        current=strtok(NULL,sep.c_str());
    }
    return arr;
}

string Book::getISBN()
{
    return ISBN;
}
string Book::getFirst()
{
    return first;
}
string Book::getlast()
{
    return last;
}
string Book::getTitle()
{
    return title;
}
 

