#include <fstream>
#include <iostream>
#include <string>
#include "BookNode.h"
#include "Book.h"
#include "BookList.h"

using namespace std;

const string CATEGORIES_FILE_NAME = "categories.txt";
void read_the_file(ifstream s);

/**
 * The main. Create and print the book lists.
 */
int main()
{
    vector<BookList>catalog;
    vector<BookNode*> array;
    string str;
    ifstream categoriesFile;
    categoriesFile.open(CATEGORIES_FILE_NAME);
    if(categoriesFile.fail())
    cout << "File failed to open." << endl;
    else{
        
        while(!categoriesFile.eof())
        {
            getline(categoriesFile, str, '\n');
            BookList newlist(str);
        }}
    
       return 0;
}



/***** Complete this file. *****/
