#ifndef BOOKLIST_H_
#define BOOKLIST_H_


#include <iostream>
#include <string>
#include "BookNode.h"
using namespace std;
class BookList
{
public:
    /**
     * Constructor.
     * @param name the name of this list.
     */
    BookList(const string name);
    
    /**
     * Print the list.
     */
    void print(BookNode* nodeptr);
    BookList();
    void create();
    BookNode* getHead();
   void insertNode(BookNode* NodeToInsert);
    
private:
    string name;      // name of this book list
    BookNode *head;   // head of the list of book nodes
    BookNode *tail;   // tail of the list of book nodes
};

#endif /* BOOKLIST_H_ */
