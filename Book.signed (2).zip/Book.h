#ifndef BOOK_H_
#define BOOK_H_
#include <string>
#include <vector>

using namespace std;

/**
 * The Book class.
 */
class Book
{
public:
    Book();
    Book(string bookdetails);
    vector<string> split_the_string(string bookdetails, string delim);
    friend ostream &operator<<(ostream &out, Book& book);
    string getISBN();
    string getFirst();
    string getlast();
    string getTitle();
    
private:
    string ISBN;
    string first;
    string last;
    string title;
};

#endif /* BOOK_H_ */

